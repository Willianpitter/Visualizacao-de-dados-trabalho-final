var dataCSV;

var csv_data;
var balao;
var tri;
var bola;
function main(){
	var svg_width = 900;
	var svg_height = 350;
	

	d3.csv("dados.csv", function(dataCSV) {
	
		// Da um o id SVG para o mapa inteiro
		var estado= d3.select("svg")
				.attr("id","SVG")
		;

		//update
		var cidade=estado.selectAll(".mod").selectAll(".mod").selectAll("g")
				.data(dataCSV)
				.style("fill",  "rgb(0,100,100)")
				.on("mousemove",function(d,i){
						var mouse=d3.mouse(estado.node()).map( function (d) {return parseInt(d);});
						var x=(mouse[0]+20);
						var y=(mouse[1]+75);
						pintacidade(dataCSV[i].codigo,dataCSV[i].cidade,dataCSV[i].populacao,x,y);
				})
				.on("mouseout",function(d,i){
						return despinta(dataCSV[i].codigo);		
				})
			;
		
		//enter
		cidade.enter().append("g")
				.style("fill",  "rgb(0,100,100)")
				.on("mousemove",function(d,i){
						var mouse=d3.mouse(estado.node()).map( function (d) {return parseInt(d);});
						var x=(mouse[0]+20);
						var y=(mouse[1]+75);
						pintacidade(dataCSV[i].codigo,dataCSV[i].cidade,dataCSV[i].populacao,x,y);
				})
				.on("mouseout",function(d,i){
						return despinta(dataCSV[i].codigo);		
				})
			;
			
		//exit
		cidade.exit().remove();
		
		
		
		
		//balao
		
		balao=estado.append("g")
			.attr("id","balao")
			.attr("visibility", "hidden")
			.attr("transform", "translate(-30,-30)" )
			.style("fill",  "rgb(255,0,100)")
			.attr("opacity", 0.9)
			;
		bola=balao.append("ellipse")
			.attr("rx",90)	
			.attr("ry",22)
			;
		tri=balao.append("path")
			.attr("d", "M 5 5 L 5 5 L 20 15 L -15 30")
			;
		
		balao.classed("hint", true);
	
		cidade=balao.append("text")
		.attr("id","cidade")
		.attr("x","0")
		.attr("y","0")
		.attr("dy","-5")
		.attr("dx","-65")
		.attr("opacity", 500)
		.style("font-size","10px")
		.style('fill','black')
		.attr("visibility", "hidden")
		;
		popula=balao.append("text")
		.attr("id","populacao")
		.attr("x","0")
		.attr("y","0")
		.attr("dy","10")
		.attr("dx","-65")
		.attr("opacity", 500)
		.style("font-size","10px")
		.style('fill','black')
		.attr("visibility", "hidden")
		;

		
		
		
	
		
	});
}
function pintacidade(idx,cidade, populacao, x, y){	
	var s=d3.select("g[id = '"+idx+"']")
		.style("fill","rgb(150,150,255)");
	var b=d3.select("#balao");
	var	t=d3.select("#cidade");
	var	p=d3.select("#populacao");
	b.attr("visibility", "visible");
	t.attr("visibility", "visible");
	p.attr("visibility", "visible");
	t.text(cidade);
	p.text("Populacao: " +populacao);
	x=x-5;
	y=y-110;
	b.attr("transform", "translate("+x+","+y+")");

}
function despinta(idx){	
	var s=d3.select("g[id = '"+idx+"']");
	s.style("fill","rgb(0,100,100)");
	var b=d3.select("#balao");
	var	t=d3.select("#cidade");
	var	p=d3.select("#populacao");
	b.attr("transform", "translate(0,0)" );
	b.attr("visibility", "hidden");
	t.attr("visibility", "hidden");
	p.attr("visibility", "hidden");
}




